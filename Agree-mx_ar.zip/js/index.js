
var language = navigator.language || navigator.browserLanguage;

if ( navigator.language === "es-AR" || navigator.language === "es-ES" ) {       
    //   alert("holaaa AR");
    }

else {
        document.location.href = 'mx/index.html';
     //   alert("holaaa MX");
    }

    